<footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
      Versi xx.xxxxx
    </div>
    <!-- Default to the left -->
    <div>
    <strong >Copyright &copy; <b style="color: blue;"> Sistem IoT </b> <a href="https://websitesaya.com" style="color: blue;">.</a>.</strong> All rights reserved.
</div>
  </footer>